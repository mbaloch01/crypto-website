
export default function Header2({ scroll, isMobileMenu, handleMobileMenu }) {
    return (
        <>

            Header2
        </>
    )
}
