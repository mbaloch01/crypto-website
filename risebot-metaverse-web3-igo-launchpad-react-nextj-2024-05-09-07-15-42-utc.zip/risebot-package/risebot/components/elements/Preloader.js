export default function Preloader() {
    return (
        <>
            <div className="preloader">
                <div className="clear-loading loading-effect-2">
                    <span />
                </div>
            </div>
        </>
    )
}
